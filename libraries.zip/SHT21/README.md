Library and example sketch for temperature and humidity sensor SHT21 (Sensirion) works with Arduino, ESP8266

This library works with temperature and humidity sensor SHT21 (Sensirion) both tested with Arduino and ESP8266. The demo sketch puts out the current temperature (Celsius) and humidity (%RH) values via the serial port.